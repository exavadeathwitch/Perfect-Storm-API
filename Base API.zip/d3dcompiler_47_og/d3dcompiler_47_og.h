#ifndef D3DCOMPILER_H 
#define D3DCOMPILER_H
#pragma once

namespace moddingApi
{
	class d3dcompiler_47_og
	{
	public:
	};
}

#endif